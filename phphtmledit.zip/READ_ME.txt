============================================
   How to Install Cute Editor for PHP
============================================

Installation instructions can be found at Deployment.htm.