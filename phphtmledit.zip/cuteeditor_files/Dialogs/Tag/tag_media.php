<fieldset><legend><?php echo GetString("Src") ; ?></legend>
	<input type="text" id="inp_src" style="width:320px" /><button id="btnbrowse"><?php echo GetString("Browse") ; ?></button>
</fieldset>
<fieldset style="height:180px;width:270px;overflow:hidden;"><legend><?php echo GetString("Demo") ; ?></legend>
	<img id="img_demo" src="" alt="" />
</fieldset>

<script type="text/javascript" src="../Scripts/Dialog/Dialog_Tag_Media.js"></script>
