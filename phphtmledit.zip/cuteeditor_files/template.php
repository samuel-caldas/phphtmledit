<html>
	<head>
		<title>Posted Values</title>
		<style type="text/css"> body { font:normal 12px arial;} table { font:normal 12px arial; }</style>
	<?php
		$vpath=$_SERVER['SCRIPT_NAME'];
		$vpath=str_replace("\\","/",$vpath);
		$vpath=dirname($vpath);
	?>	
		<link type="text/css" rel="stylesheet" href='<?php echo $vpath ; ?>/Style/SyntaxHighlighter.css' />
	</head>
	<body>
	
	</body>
</html>